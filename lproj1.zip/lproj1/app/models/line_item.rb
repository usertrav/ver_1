class LineItem < ApplicationRecord::Base
	belongs_to :book
end
