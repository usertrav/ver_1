Rails.application.routes.draw do
  resources :books
  resources :line_items
  resources :products
  resources :user
   get "products/index"
get "user/new_user"
 root :to => 'books#index'

 get 'edit', to: 'books#edit'
  get'index', to: 'books#index'
  get 'new', to:'books#new'
  get 'show', to: 'books#show'


 get 'edit', to: 'user#edit'
  get'login', to: 'user#login'
  get 'new', to:'user#new_user' 
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
